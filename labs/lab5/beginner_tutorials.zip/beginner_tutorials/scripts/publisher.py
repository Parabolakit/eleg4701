#!/usr/bin/env python  
# -*- coding: utf-8 -*-

# Finish all TODOs.

import sys
import rospy

# TODO 1: import turtlesim/Pose message.
from turtlesim.msg import Pose
# TODO 2: import your Mypose message.
from beginner_tutorials.msg import Mypose


def pose_callback(pose):
    rospy.loginfo("Robot 1 X = %f: Y=%f: Z = %f\n", pose.x, pose.y, pose.theta)
    mp.x = pose.x
    mp.y = pose.y
    mp.theta = pose.theta

    # TODO 3: assign the subscribed pose to your mp.x, mp.y, mp.theta.


if __name__ == '__main__':
    # TODO 4: initialize node 'pub_turtle'
    rospy.init_node('pub_turtle', anonymous=True)
    # TODO 5: define a publisher: topic name is '/turtle1/mypose'. 
    pub = rospy.Publisher('turtle1/mypose', Mypose, queue_size=10)
    # TODO 6: define a subscriber: topic name is '/turtle1/pose'. 
    rospy.Subscriber('/turtle1/pose', Pose, pose_callback)

    # TODO 7: initialize the variable mp with your message type.  
    global mp
    mp = Mypose()
    rate = rospy.Rate(10) 
    while not rospy.is_shutdown():

        # TODO : publish mp.
	pub.publish(mp)
        rate.sleep()             

